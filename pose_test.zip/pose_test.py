'''

    Demonstration of Joint2Angle and Angle2Joint 
 
    To extract local axis-angles to compare the two poses of joints set
        

    (c) heejune@seoultech.ac.kr 
       J2 
        \
         \   
          \
          J1  pose defined from parent's local frame 
         /    The local frame at J1 is define Mparent*R(pose) 
        /  
       / 
     J0 Mlocal = I  (now starting world coordinate)  
                                                (SMPL has different defintion)
'''


import numpy as np
import cv2
import os
import matplotlib.pyplot as plt


def visualize_joints( j3ds, bones,  up_view=5, side_view=15, x_lim=[-4, 4],
                     y_lim=[-4, 4], z_lim=[0, 4]):
   
    fig = plt.figure()
    njoints = len(j3ds)
    
    for i, j3d in enumerate(j3ds):
 
        ax = fig.add_subplot(1, njoints, i+1, projection='3d')
       
        ax.set_xlim(x_lim)
        ax.set_ylim(y_lim)
        ax.set_zlim(z_lim)
        ax.set_xlabel('$X$')
        ax.set_ylabel('$Y$')
        ax.set_zlabel('$Z$')
        if i == 0:
            ax.set_title('input joints')
        else:
            ax.set_title('recon. joints')
        
        ax.view_init(up_view, side_view)
        
        for bone_idx in range(len(bones)):
            ax.plot( j3d[bones[bone_idx], 0], j3d[bones[bone_idx], 1], j3d[bones[bone_idx], 2], linewidth=2.0);
        
      
    plt.show()    
    
    
def joints2poses(joints, debug = False):
    '''
      convert 3d joints positions into rodrigues angles in local coordinates  
      @TODO the 0 joint's angle should be used !!!
      @TODO bug fixing for the downward direction    
    
    '''

    poses_g  = np.zeros_like(joints)  # pose in global coorinate  
    rotmat_g = np.zeros((len(joints),3,3))
    limbs    = np.zeros_like(joints)    
  
    # 1. rotations in the world/global coordinate  
    # 
    #    Jn-2 =====>Jn-1=====u=====> Jn 
    #   
    
    # @TODO-1 initial coordinate ...^^^;;;
    poses_g[0,:] = 0  #?
    rotmat_g[0,:] = cv2.Rodrigues(poses_g[0,:])[0]
    for j in range(1, len(joints)):
        #print(f"j:{j}")
        
        # 1.1 P1, P2, P2 => v, u 
        u = joints[j,:] - joints[j-1,:]
        limbs[j, 2] = np.linalg.norm(u)
        if j == 1:  
            v = np.array([0.,0.,1.]) # @TODO-2, Z direction of joint 0 
        else:
            v = joints[j-1,:] - joints[j-2,:]

        inner = np.inner(v,u)             
        angle = np.arccos(inner/(np.linalg.norm(v)*np.linalg.norm(u)) )
        print(f"agnle:{angle}")
        if angle < 10e-9 :    
            axis_angle = np.zeros(3)
            if debug:
                print(f"u:{u}, v:{v}, cross: ----, inner:{inner}, angle:{angle}, rvec:{axis_angle}")
        elif angle > np.pi- 10e-9:
            axis = np.array([0.0, 1.0, 0.0])  # x or y willbe OK
            axis_angle = angle*axis/np.linalg.norm(axis) # any direction not same as u will be ok 
        else:        
            axis = np.cross(v,u)
            axis = axis/np.linalg.norm(axis)
            axis_angle = angle*axis 
            if debug:    
                print(f"u:{u}, v:{v}, cross:{axis}, inner:{inner}, angle:{angle}, rvec:{axis_angle}")
        poses_g[j,:] = axis_angle
        rotmat_g[j,:] = cv2.Rodrigues(axis_angle)[0]
    
    if debug:
        print(f"poses_g:{poses_g}")
        print(f"rotmat_g:{rotmat_g}")
    
    # 2. define local coorindate and express the global poses in local coorindate 
    poses_l  = np.zeros_like(joints)  # pose in local coorinate    
    Mlocal  = np.eye(3)
    for j in range(1, len(joints)):
        poses_l[j,:] =  np.linalg.inv(Mlocal)@poses_g[j,:]  
        Mlocal = rotmat_g[j,:,:]@Mlocal
     
    if debug: 
        print(f"poses_l:{poses_l}")
    
    return poses_l, limbs
    
def poses2joints(init_pos, poses, limbs, debug = False):

    ''' limb's rest direction is z  '''

    joints = np.zeros_like(poses)
    # initial position and local frame   
    joints[0,:] = init_pos
    Mlocal = np.eye(3)  

    for j in range(1, len(poses)):  # from 1 ( if we have 0, it is used for global)
        Rpos = cv2.Rodrigues(poses[j,:])[0]
        #print(f"Rpos:{Rpos} <= pose:{poses[j,:]}")
        Mlocal = Mlocal@Rpos  # local cooridinate at j 
        #print(f"Mlocal:{Mlocal}@ limb :{limbs[j,:]} = {Mlocal.dot(limbs[j,:])}")
        joints[j,:] = joints[j-1,:] + Mlocal.dot(limbs[j,:])
        
    return joints
    

def demo_rodrigues():

    print("test zero rotation")
    r  = np.eye(3)
    print(f"r:{r}")
    rv = cv2.Rodrigues(r)[0]
    print(f"rv:{rv}")
    r = cv2.Rodrigues(rv)[0]
    print(f"r:{r}")

    print("test 90 degree around z rotation")
    r  = np.array([[0., -1,  0],
                   [1, 0,  0],
                   [0, 0,  1]])
    print(f"r:{r}")
    rv = cv2.Rodrigues(r)[0]
    print(f"rv:{rv}")
    r = cv2.Rodrigues(rv)[0]
    print(f"r:{r}")

    print("test -90 degree around z rotation")
    r  = np.array([[0., 1,  0],
                   [-1, 0,  0],
                   [0, 0,  1]])
    print(f"r:{r}")
    rv = cv2.Rodrigues(r)[0]
    print(f"rv:{rv}")
    r = cv2.Rodrigues(rv)[0]
    print(f"r:{r}")
    
    print("test 180 degree around z rotation")
    r  = np.array([[-1., 0,  0],
                   [0, -1,  0],
                   [0, 0,  1]])
    print(f"r:{r}")
    rv = cv2.Rodrigues(r)[0]
    print(f"rv:{rv}")
    r = cv2.Rodrigues(rv)[0]
    print(f"r:{r}")
    
    print("test -180 degree around z rotation")
    r  = np.array([[-1., 0,  0],
                   [0, -1,  0],
                   [0, 0,  1]])
    print(f"r:{r}")
    rv = cv2.Rodrigues(r)[0]
    print(f"rv:{rv}")
    r = cv2.Rodrigues(rv)[0]
    print(f"r:{r}")


    print("test 90 degree around x rotation")
    r  = np.array([[1., 0,  0],
                   [0, 0,  -1],
                   [0, 1,  0]])
    print(f"r:{r}")
    rv = cv2.Rodrigues(r)[0]
    print(f"rv:{rv}")
    r = cv2.Rodrigues(rv)[0]
    print(f"r:{r}")


def demo(joints, bones, debug = False):

    # 1. defining the joints
    print(f"joints:{joints}")
    
    # 2. joints to local rotations 
    pose, limbs = joints2poses(joints, debug)
    print(f"local pose:{pose}")
    print(f"limbs:{limbs}")
    
    #visualize_joints([joints], bones)
    
    # 3. rotation & offset back to joints 
    joints2 = poses2joints(np.zeros(3), pose, limbs)  
    print(f"joints:{joints}")   
    print(f"joints2:{joints2}")
    visualize_joints([joints, joints2], bones) 


if __name__ == "__main__":
   
    np.set_printoptions(precision=1)
    np.set_printoptions(suppress=True)
    sqrt2 = np.sqrt(2)
 
    #demo_rodrigues()

    # current a simple one way hierachy only 
    bones = [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5]]

    # pose with simple angles upwards 
    test_joints = np.array( [[0.,0.,0.], [0., 0., 1.], [0., 1., 1. ],  [1., 1. , 1. ], [1., 2., 1. ], [1., 2. , 2. ]])
    demo(test_joints, bones )
    
    # pose with difficult angles upwards
    test_joints = np.array( [[0,0,0], [0, 0, 1], [0, 1 + sqrt2, 1 + sqrt2],  [1, 1 + sqrt2, 1 + sqrt2], [1, 2 + sqrt2, 1 + sqrt2], [1, 2 + sqrt2, 2 + sqrt2]])
    demo(test_joints, bones)

    # pose with difficult angles upwards
    test_joints = np.array( [[0,0,0], [0, 0, 1], [0, 1.5, 1 ],  [1.2, 1 + 1.4, 1 + 0.5], [1.3, 2 + sqrt2, 1 + sqrt2], [1.4, 2 + sqrt2, 2 + sqrt2]])
    demo(test_joints, bones)
    
    # pose in downward direction  
    test_joints  = np.array( [[0.,0.,0.], [0., 0., -1.], [0., -1., -1. ],  [-1., -1. , -1. ], [-1., -2., -1. ], [-1., -2. , -2. ]])
    demo(test_joints, bones, debug = False)
    