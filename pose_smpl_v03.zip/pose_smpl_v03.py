'''

    Demonstration of Joint2Angle and Angle2Joint 
 
    To extract local axis-angles to compare the two poses of joints set
        

    (c) heejune@seoultech.ac.kr 
       J2 
        \
         \   
          \
          J1  pose defined from parent's local frame 
         /    The local frame at J1 is define Mparent*R(pose) 
        /  
       / 
     J0 Mlocal = I  (now starting world coordinate)  
                                                (SMPL has different defintion)
'''


import numpy as np
import cv2
import os
import matplotlib.pyplot as plt


def visualize_joints( j3ds, bones,  up_view=5, side_view=15, x_lim=[-4, 4],
                     y_lim=[-4, 4], z_lim=[0, 4]):
   
    fig = plt.figure()
    njoints = len(j3ds)
    
    for i, j3d in enumerate(j3ds):
 
        ax = fig.add_subplot(1, njoints, i+1, projection='3d')
       
        ax.set_xlim(x_lim)
        ax.set_ylim(y_lim)
        ax.set_zlim(z_lim)
        ax.set_xlabel('$X$')
        ax.set_ylabel('$Y$')
        ax.set_zlabel('$Z$')
        if i == 0:
            ax.set_title('input joints')
        else:
            ax.set_title('recon. joints')
        
        ax.view_init(up_view, side_view)
        
        for bone_idx in range(len(bones)):
            ax.plot( j3d[bones[bone_idx], 0], j3d[bones[bone_idx], 1], j3d[bones[bone_idx], 2], linewidth=2.0);
        
      
    plt.show()    
    
    
def joints2poses(joints, parents, debug = False):
    '''
      convert 3d joints positions into rodrigues angles in local coordinates  
      @TODO the 0 joint's angle should be used !!!
      @TODO bug fixing for the downward direction    
    
    '''

    poses_g  = np.zeros_like(joints)  # pose in global coorinate  
    rotmat_g = np.zeros((len(joints),3,3))
    limbs    = np.zeros_like(joints)    
  
    # 1. rotations in the world/global coordinate  
    # 
    #    Jn-2 =====>Jn-1=====u=====> Jn 
    #   
    
    # @TODO-1 initial coordinate ...^^^;;;
    # 
    # 
    #       *J0
    #      /
    #     /
    # J-1*
    #
    poses_g[0,:] = 0  #?
    rotmat_g[0,:] = cv2.Rodrigues(poses_g[0,:])[0]
    for j in range(1, len(joints)):

        parent_j = parents[j]
        
        # 1.1 P1, P2, P2 => v, u 
        u = joints[j,:] - joints[parent_j,:]
        limbs[j, 2] = np.linalg.norm(u)
        if parent_j == 0:  
            v = np.array([0.,0.,1.]) # @TODO-2, Z direction of joint 0 
        else:
            grandparent_j = parents[parent_j]
            v = joints[parent_j,:] - joints[grandparent_j,:]
        
        if debug:
            print(f"v:{v}, u:{u}")
        
        inner = np.inner(v,u)   
        norm = np.linalg.norm(v)*np.linalg.norm(u)
        if abs(norm) < 10e-9:
            print("too small norms")  
            return     
        angle = np.arccos(inner/norm)
        print(f"angle:{angle}")
        if angle < 10e-9 :    
            axis_angle = np.zeros(3)
            if debug:
                print(f"u:{u}, v:{v}, cross: ----, inner:{inner}, angle:{angle}, rvec:{axis_angle}")
        elif angle > np.pi- 10e-9:
            axis = np.array([0.0, 1.0, 0.0])  # x or y willbe OK
            axis_angle = angle*axis/np.linalg.norm(axis) # any direction not same as u will be ok 
        else:        
            axis = np.cross(v,u)
            axis = axis/np.linalg.norm(axis)
            axis_angle = angle*axis 
            if debug:    
                print(f"u:{u}, v:{v}, cross:{axis}, inner:{inner}, angle:{angle}, rvec:{axis_angle}")
        poses_g[j,:] = axis_angle
        rotmat_g[j,:] = cv2.Rodrigues(axis_angle)[0]
    
    if debug:
        print(f"poses_g:{poses_g}")
        print(f"rotmat_g:{rotmat_g}")
    
    # 2. define local coorindate and express the global poses in local coorindate 
    poses_l  = np.zeros_like(joints)  # pose in local coorinate    
    frames  = np.zeros((len(joints), 3, 3))
    frames[0, :,:] = np.eye(3)
    for j in range(1, len(joints)):
        parent_j = parents[j]
        poses_l[j,:] =  np.linalg.inv(frames[parent_j])@poses_g[j,:]  
        frames[j]    =  rotmat_g[j,:,:]@frames[parent_j]

    if debug: 
        print(f"poses_l:{poses_l}")
    
    return poses_l, limbs
 

def poses2joints(base_loc, poses, limbs, parents, debug = False):

    joints = np.zeros_like(poses)
    joints[0,:] = base_loc
    frames = np.zeros((len(poses),3,3))
    frames[0,:,:] = cv2.Rodrigues(poses[0,:])[0]
    
    for j in range(1, len(poses)): 
        parent_j = parents[j]
        Rpos = cv2.Rodrigues(poses[j,:])[0]
        if debug:
            print(f"{frames[parent_j,:,:] @ Rpos @limbs[j,:]} = {frames[parent_j,:,:]}, {Rpos}, {limbs[j,:]}")
        joints[j, :]  = joints[parent_j, : ] + frames[parent_j,:,:] @ Rpos @limbs[j,:]
        frames[j,:,:] = frames[parent_j,:,:]@Rpos
    
    return joints
    

def demo_rodrigues():

    print("test zero rotation")
    r  = np.eye(3)
    print(f"r:{r}")
    rv = cv2.Rodrigues(r)[0]
    print(f"rv:{rv}")
    r = cv2.Rodrigues(rv)[0]
    print(f"r:{r}")

    print("test 90 degree around z rotation")
    r  = np.array([[0., -1,  0],
                   [1, 0,  0],
                   [0, 0,  1]])
    print(f"r:{r}")
    rv = cv2.Rodrigues(r)[0]
    print(f"rv:{rv}")
    r = cv2.Rodrigues(rv)[0]
    print(f"r:{r}")

    print("test -90 degree around z rotation")
    r  = np.array([[0., 1,  0],
                   [-1, 0,  0],
                   [0, 0,  1]])
    print(f"r:{r}")
    rv = cv2.Rodrigues(r)[0]
    print(f"rv:{rv}")
    r = cv2.Rodrigues(rv)[0]
    print(f"r:{r}")
    
    print("test 180 degree around z rotation")
    r  = np.array([[-1., 0,  0],
                   [0, -1,  0],
                   [0, 0,  1]])
    print(f"r:{r}")
    rv = cv2.Rodrigues(r)[0]
    print(f"rv:{rv}")
    r = cv2.Rodrigues(rv)[0]
    print(f"r:{r}")
    
    print("test -180 degree around z rotation")
    r  = np.array([[-1., 0,  0],
                   [0, -1,  0],
                   [0, 0,  1]])
    print(f"r:{r}")
    rv = cv2.Rodrigues(r)[0]
    print(f"rv:{rv}")
    r = cv2.Rodrigues(rv)[0]
    print(f"r:{r}")


    print("test 90 degree around x rotation")
    r  = np.array([[1., 0,  0],
                   [0, 0,  -1],
                   [0, 1,  0]])
    print(f"r:{r}")
    rv = cv2.Rodrigues(r)[0]
    print(f"rv:{rv}")
    r = cv2.Rodrigues(rv)[0]
    print(f"r:{r}")

def demo_smpl(debug = False):
 
    # current a simple one way hierachy only 
    #                 - 13 - 16 [lsh] - 18 [lelb] - 20 [lwr] - 22
    #       3 - 6 - 9 - 12 - 15
    #                 - 14 - 17 [rsh] - 19 [relb] - 21 [rwr] - 23
    # 0 - 
    #       1 [lhip] - 4 [lknee] - 7 [lankle] - 10
    #       2 [rhip] - 5 [rknee] - 8 [rankle] - 11  
    #
    #                  0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20,21,22,23               
    smpl_parents = [None, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9,12,13,14,16,17,18,19,20,21]    
    '''
    smpl_children= { 0: [1,2,3],
                1: [4],
                2: [5],
                3: [6,13,14],
                4: [7],
                5: [8],
                6: [9],
                7: [10],
                8: [11],
                9: [12],
                10:[],
                11:[],
                12:[15],
                13:[16],
                14:[17],
                15:[],
                16:[18],
                17:[19],
                18:[20],
                19:[21],
                20:[22],
                21:[23],
                22:[],
                23:[]}
    '''           
    #bones = [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5]]
    smpl_bones = []
    for j in range(1, len(smpl_parents)):
        smpl_bones.append([j, smpl_parents[j]]) 
    
    
    if False:
       #                  0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12             
        smpl_parents = [None, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9]    
        smpl_bones = []
        for j in range(1, len(smpl_parents)):
            smpl_bones.append([j, smpl_parents[j]]) 
  
        smpl_joints = np.array( [                        [0.,0.,0.], 
                            [.5, 0.,-.5], [-.5,0.,-.5],      [0., 0., .5],
                            [.5, 0.,-1.5],[-.5,0.,-1.5],     [0., 0., 1.5],
                            [.5, 0.,-2.5],[-.5,0.,-2.5],     [0., 0., 2.5],
                            [.5,-2.5,-2.5],[-.5,-2.5,-2.5],    [0., 0., 3.0]])
    
    elif False:
        smpl_joints = np.array( [                        [0.,0.,0.], 
                            [.5, 0.,-.5], [-.5,0.,-.5],      [0., 0., .5],
                            [.5, 0.,-1.5],[-.5,0.,-1.5],     [0., 0., 1.5],
                            [.5, 0.,-2.5],[-.5,0.,-2.5],     [0., 0., 2.5],
                            [.5,-.5,-2.5],[-.5,-.5,-2.5],    [0., 0., 3.0], [1., 0.,2.8], [-1., 0.,2.8],
                                                             [0., 0., 4.0], [1.5,0.,3.], [-1.5, 0.,3.],
                                                                            [2., 0.,3.], [-2., 0.,3.],                                   
                                                                            [3., 0.,3.], [-3., 0.,3.],
                                                                            [4., 0.,3.], [-4., 0.,3.]])
    else:

        smpl_joints = np.array([[0., 0., 0.],
                            [.5, 0., -.5], [-.5, 0., -.5], [0., 0., .5],
                            [.5, 0., -1.5], [-.5, 0., -1.5], [0., 0., 1.5],
                            [.5, 0., -2.5], [-.5, 0., -2.5], [0., 0., 2.5],
                            [.5, -.5, -2.5], [-.5, -.5, -2.5], [0., 0., 3.0], [1., 0., 2.8], [-1., 0., 2.8],
                                                               [0., 0., 4.0], [1.5, 0., 3.], [-1.5, 0., 3.],
                                                                              [2., 1., 2.], [-2., 1., 2.],
                                                                              [2, 1., 1.], [-2, 1., 1.],
                                                                              [2, 1., 0.5], [-2, 1., 0.5]])    
                            
    base_pos = np.array([0.0, 0.0, 0.0])                         
    smpl_joints = smpl_joints  + base_pos                           
    #visualize_joints([smpl_joints], smpl_bones) 
    poses, limbs = joints2poses(smpl_joints, smpl_parents, debug)
    print(f"local pose:{poses}")
    print(f"limbs:{limbs}")
    
    #visualize_joints([smpl_joints], smpl_bones)
    
    # 3. rotation & offset back to joints 
    joints2 = poses2joints(base_pos, poses, limbs, smpl_parents, debug = True)
    print(f"compare joints:{np.dstack((smpl_joints,joints2))}")
    
    visualize_joints([smpl_joints, joints2], smpl_bones)
   

if __name__ == "__main__":
   
    np.set_printoptions(precision=1)
    np.set_printoptions(suppress=True)
 
    #demo_rodrigues()
    demo_smpl()